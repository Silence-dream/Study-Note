# **[uni-app-starter](https://github.com/SunSeekerX/uni-app-starter)**

> uni-app业务解决集成方案。
>
> 用来记录使用 uni-app 之中出现的问题、踩过的坑、解决业务的写法、工具函数、通用组件。


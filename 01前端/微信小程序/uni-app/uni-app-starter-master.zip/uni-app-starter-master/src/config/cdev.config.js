/**
 * @name:
 * @author: SunSeekerX
 * @Date: 2020-11-05 20:03:22
 * @LastEditors: SunSeekerX
 * @LastEditTime: 2020-11-05 20:04:43
 */

// 默认的baseurl
export const DEFAULT_BASE_API = 'http://dev.entry.bandex.lvyii.com'
// 热更新的baseurl
export const UPDATE_BASE_API = 'http://10.10.10.1:3000'

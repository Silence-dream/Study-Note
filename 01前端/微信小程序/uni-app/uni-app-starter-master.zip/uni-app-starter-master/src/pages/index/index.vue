<template>
  <view>index</view>
</template>

<script>
export default {
  name: 'Index',
  data() {
    return {}
  },
  methods: {},
}
</script>

<style lang="scss" scoped></style>

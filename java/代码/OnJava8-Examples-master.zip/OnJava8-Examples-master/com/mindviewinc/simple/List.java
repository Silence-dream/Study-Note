// com/mindviewinc/simple/List.java
// (c)2017 MindView LLC: see Copyright.txt
// We make no guarantees that this code is fit for any purpose.
// Visit http://OnJava8.com for more book information.
// Creating a package
package com.mindviewinc.simple;

public class List {
  public List() {
    System.out.println("com.mindviewinc.simple.List");
  }
}

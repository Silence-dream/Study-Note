// generics/watercolors/Watercolors.java
// (c)2017 MindView LLC: see Copyright.txt
// We make no guarantees that this code is fit for any purpose.
// Visit http://OnJava8.com for more book information.
package generics.watercolors;

public enum Watercolors {
  ZINC, LEMON_YELLOW, MEDIUM_YELLOW, DEEP_YELLOW,
  ORANGE, BRILLIANT_RED, CRIMSON, MAGENTA,
  ROSE_MADDER, VIOLET, CERULEAN_BLUE_HUE,
  PHTHALO_BLUE, ULTRAMARINE, COBALT_BLUE_HUE,
  PERMANENT_GREEN, VIRIDIAN_HUE, SAP_GREEN,
  YELLOW_OCHRE, BURNT_SIENNA, RAW_UMBER,
  BURNT_UMBER, PAYNES_GRAY, IVORY_BLACK
}

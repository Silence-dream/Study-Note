# typescript-uni-app-with-eslint

## Project setup
```
npm install
```

### 生成uni-app的manifest.json文件
```
npm run dev:manifest
npm run build:manifest
```

### Compiles and minifies for production(h5)
```
npm run build
```

### 编译生成微信小程序
```
npm run build:mp-weixin
npm run dev:mp-weixin
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
